from distutils.core import setup

setup(
		name = 'nester',
		version = '1.0.0',
		py_modules = ['nester'],
		author = 'Grace',
		author_email = 'grace@example.com',
		url = 'http://headfirstlab.com',
		description = 'A simple printer of nested lists.',
		)
